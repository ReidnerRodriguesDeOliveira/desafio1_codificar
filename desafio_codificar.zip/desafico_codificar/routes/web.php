<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::group(['prefix' => 'orcamento'], function(){
    Route::get('/', ['uses' => 'orcamentoController@lista', 'as' => 'orcamento.index']);
    Route::get('/form', ['uses' => 'orcamentoController@novo', 'as' => 'orcamento.form']);
    Route::post('/salvar', ['uses' => 'orcamentoController@salvar', 'as' => 'orcamento.salvar']);
});


