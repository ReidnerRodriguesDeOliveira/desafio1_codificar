@extends('template\app')
@section('titulo', 'venda')

<html>
<head> 
    <meta charset-"utf8">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="{{asset('css/materialize.min.css')}}" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="{{asset('css/materialize.css')}}" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="{{asset('css/style.css')}}" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>

<body>

<div class="container ">
          <div class="row">
            <div class="col s12 center z-depth-2 white hoverable">
              <h3><i class="mdi-content-send brown-text"></i></h3>
              <h4 class="center teal-text">lista de orçamentos<i class="material-icons">assignment</i></h4>
              <table class="centered highlight responsive-table ">
            <tr> 
            <thead>   
                <th>id</th>
                <th>nome_cliente</th>
                <th>data_orcamento</th>
                <th>vendedor</th>
                <th>descricao</th>
                <th>valor_orcamento</th>
            </thead>
            </tr>
            @foreach($dados as $atual)
            <tr>
            <tbody>
                <td>{{$atual['id']}}</td>
                <td>{{$atual['nome_cliente']}}</td>
                <td>{{$atual['data_orcamento']}}</td>
                <td>{{$atual['vendedor']}}</td>
                <td>{{$atual['descricao']}}</td>
                <td>{{$atual['valor_orcamento']}}</td>
            </tbody>    
            </tr>
            @endforeach
        </table>
        <br>
        <a href="/orcamento/form" class="btn btn-success left">cadastrar</a>
        <br><br>
            </div>
          </div>

        </div>
      </div>

        
</body>
</html>