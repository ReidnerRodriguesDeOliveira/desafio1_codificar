<html>
<head>
<title>@yield('titulo')</title>
</head>
</html>