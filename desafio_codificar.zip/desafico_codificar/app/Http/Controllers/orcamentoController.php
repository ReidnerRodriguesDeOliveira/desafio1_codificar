<?php

namespace App\Http\Controllers;
use App\orcamento;
use App\Http\Requests\orcamentoRequest;
use Illuminate\Http\Request;

class orcamentoController extends Controller
{
    public function lista()
    {
        $dados = orcamento::All();
        return view('orcamento.index', compact('dados'));
    }

    public function novo()
    {
        return view('orcamento.form');
    }

    public function salvar(orcamentoRequest $dados)
    {
        orcamento::create($dados->all());
        return redirect(route('orcamento.index'));

    }
}
