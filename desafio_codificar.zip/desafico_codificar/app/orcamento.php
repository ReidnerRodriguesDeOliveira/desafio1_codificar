<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class orcamento extends Model
{
    protected $table = 'vendas';
    public $timestamp = true;
    protected $primaryKey = 'id';
    protected $fillable = ['nome_cliente', 'data_orcamento', 'vendedor', 'descricao', 'valor_orcamento'];

    public function salvar($dados){

        $dados = upperVar($dados);

        if(!empty($dados['id'])){
            return this::where('id', $dados['id'])->update($dados);
        }else{
            return $this::create($dados);
        }
    }
}
