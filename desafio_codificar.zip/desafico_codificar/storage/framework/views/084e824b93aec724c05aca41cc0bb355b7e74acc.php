<?php $__env->startSection('titulo', 'formulario de cadastro'); ?>
<html>
    <head>
    <meta charset-"utf8">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="<?php echo e(asset('css/materialize.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="<?php echo e(asset('css/materialize.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="<?php echo e(asset('css/style.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection"/>
    </head>
<script>

</script>
    <body>
    
<div class="container ">
    <div class="row">
        <div class="col s12 center z-depth-2 white hoverable">
            <h3><i class="mdi-content-send brown-text"></i></h3>
            <h4 class="center teal-text">Cadastro de orçamentos<i class="material-icons">assignment</i></h4>

            <form action="<?php echo e(route('orcamento.salvar')); ?>" method="post" class="col s12">
            <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-md-12 justify-content-center">
                        <div class=" form-group bg ">
                            <div class=" input-field col s6">
                                <h6 class="left cor" for="id">id</h6>
                                <input type="Text" name="id" id="id" disabled>
                            </div>

                            <div class=" input-field col s6">
                                <h6 class="left cor" for="nome_cliente">nome do cliente</h6>
                                <input type="text" name="nome_cliente" id="nome_cliente" class="validate">
                            </div>

                            <div class="input-field col s6">
                                <h6 class="left cor" for="idata_orcamentod">data do orcamento</h6>
                                <input type="date" name="data_orcamento" id="data_orcamento" class="validate">
                            </div>
                            <div class="input-field col s6">
                                <h6 class="left cor" for="vendedor">vendedor</h6>
                                <input type="Text" name="vendedor" id="vendedor" class="validate">
                            </div>

                            <div class="input-field col s6">
                                <h6 class="left cor" for="valor_orcamento">valor do orcamento</h6>
                                <input type="number" name="valor_orcamento" id="valor_orcamento" class="validate">
                            </div> 

                            <div class="input-field col s6">
                                <h6 class="left cor" for="descricao">descricao</h6>
                                <textarea id='descricao' class='materialize-textarea' name='descricao' ></textarea>
                            </div>
                            
                            <div class="col s12 ">
                            <input type="submit" class="btn btn-success left" value="Cadastrar" id="cadastrar" name="cadastrar">
                            <a href="<?php echo e(route('orcamento.index')); ?>" class="btn red left">cancelar</a>
                            </div>
                        </div>    
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

    </body>
</html>
<?php echo $__env->make('template\app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\desafico_codificar\resources\views/orcamento/form.blade.php ENDPATH**/ ?>