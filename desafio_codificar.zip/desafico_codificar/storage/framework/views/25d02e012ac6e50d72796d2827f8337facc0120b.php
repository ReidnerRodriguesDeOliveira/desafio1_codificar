<html>
<head>
<title><?php echo $__env->yieldContent('titulo'); ?></title>
</head>
</html><?php /**PATH C:\wamp64\www\desafico_codificar\resources\views/template\app.blade.php ENDPATH**/ ?>