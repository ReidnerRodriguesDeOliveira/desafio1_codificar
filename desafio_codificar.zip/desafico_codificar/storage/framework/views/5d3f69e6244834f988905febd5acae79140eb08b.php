<?php $__env->startSection('titulo', 'venda'); ?>

<html>
<head> 
    <meta charset-"utf8">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="<?php echo e(asset('css/materialize.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="<?php echo e(asset('css/materialize.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="<?php echo e(asset('css/style.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>

<body>

<div class="container ">
          <div class="row">
            <div class="col s12 center z-depth-2 white hoverable">
              <h3><i class="mdi-content-send brown-text"></i></h3>
              <h4 class="center teal-text">lista de orçamentos<i class="material-icons">assignment</i></h4>
              <table class="centered highlight responsive-table ">
            <tr> 
            <thead>   
                <th>id</th>
                <th>nome_cliente</th>
                <th>data_orcamento</th>
                <th>vendedor</th>
                <th>descricao</th>
                <th>valor_orcamento</th>
            </thead>
            </tr>
            <?php $__currentLoopData = $dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atual): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <tbody>
                <td><?php echo e($atual['id']); ?></td>
                <td><?php echo e($atual['nome_cliente']); ?></td>
                <td><?php echo e($atual['data_orcamento']); ?></td>
                <td><?php echo e($atual['vendedor']); ?></td>
                <td><?php echo e($atual['descricao']); ?></td>
                <td><?php echo e($atual['valor_orcamento']); ?></td>
            </tbody>    
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <br>
        <a href="/orcamento/form" class="btn btn-success left">cadastrar</a>
        <br><br>
            </div>
          </div>

        </div>
      </div>

        
</body>
</html>
<?php echo $__env->make('template\app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\desafico_codificar\resources\views/orcamento/index.blade.php ENDPATH**/ ?>